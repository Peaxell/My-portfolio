// src/components/Portfolio.jsx
import React from 'react';
import image1 from './Image/2.jpg'

import image2 from './Image/6.jpg'

import image3 from './Image/3.jpg'
const Portfolio = () => {
  const projects = [
    { 
      title: "Modern E-Commerce Redesign", 
      description: "Redesigned an e-commerce site to improve usability, resulting in a 25% increase in engagement and 15% boost in sales.",
      techStack: "React, Tailwind CSS, Node.js, MongoDB", 
      img: image1
    },
    { 
      title: "Interactive Data Visualization Dashboard", 
      description: "Built a dashboard with data filters and custom graphs for real-time insights, focusing on accessibility and usability.",
      techStack: "React, D3.js, Tailwind CSS, REST APIs", 
      img: image2
    },
    { 
      title: "Creative Portfolio Showcase", 
      description: "Developed a portfolio with animations and smooth transitions, resulting in multiple high-profile client projects.",
      techStack: "React, Tailwind CSS, Framer Motion", 
      img:image3
    },
  ];
  

  return (
    <section className="py-20 bg-gray-100 text-primary" id="portfolio">
      <div className="container mx-auto px-6 md:px-12">
        <h2 className="text-3xl font-semibold text-center">Portfolio</h2>
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-white shadow-lg rounded-lg p-6">
              <img src={project.img} alt={project.title} className="w-full h-48 object-cover rounded-md" />
              <h3 className="text-2xl font-bold mt-4">{project.title}</h3>
              <p className="text-gray-700 mt-2">{project.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
