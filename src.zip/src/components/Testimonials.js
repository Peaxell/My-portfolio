// src/components/Testimonials.jsx
import React from 'react';

const testimonials = [
  { text: "Working with John was a pleasure! His expertise brought our project to life in ways we couldn't have imagined.", author: "Jane Smith, CEO of TechCorp" },
  { text: "John’s attention to detail and creativity exceeded our expectations. Highly recommended!", author: "Michael Brown, Founder of StartItUp" },
];

const Testimonials = () => {
  return (
    <section className="py-20 bg-gray-100 text-primary" id="testimonials">
      <div className="container mx-auto px-6 md:px-12 text-center">
        <h2 className="text-3xl font-semibold">Testimonials</h2>
        <div className="mt-8 flex flex-col md:flex-row gap-8 justify-center">
          {testimonials.map((item, index) => (
            <div key={index} className="bg-white shadow-lg p-6 rounded-lg max-w-md">
              <p className="text-lg">"{item.text}"</p>
              <h3 className="mt-4 font-semibold">{item.author}</h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
